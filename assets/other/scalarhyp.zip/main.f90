program gbssnsphersym
  use mol
  use parameters_mod
  use grid, xp => gridvect
  use output
  use command_line

  implicit none

  type(parameters_type)   :: parameters, parameters_old
  integer:: i, j, k, last_step, conv_level
  character(len=120)  :: attach
  real(kind=wp) :: start, finish, conv_fact
  integer :: extra

  call cpu_time(start)

  call read_params(parameters, file_names, file_prefix, conv_level, attach)

if(parameters%slice%h.lt.0) then
  select case (parameters%moldef%deriv_method)
	case ('c8')
		extra=3
	case ('c6')
		extra=2
	case default
		extra=1
  end select
elseif(parameters%slice%h.gt.0) then
	extra=1
else
	stop 'Set h!'
endif

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! convergence testing
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  do k=1, conv_level
 parameters_old = parameters
 file_names_old = file_names
 if (conv_level == 1) then
 call change_file_names(file_names, parameters,'single')
 else
 call change_file_names(file_names, parameters, &
   & trim(attach)//achar(iachar("0")+ k))
 end if
 call main(k)
 parameters = parameters_old
 file_names = file_names_old
 if (parameters%grid%origin.eq.'nostag') conv_fact = 2.0_wp
 if (parameters%grid%origin.eq.'stag') conv_fact = 3.0_wp ! if automatic convergence form desired (check that stagdiff is set to the correct values, not zero, in output.f90), otherwise choose 1.5_wp
 if (parameters%grid%origin.eq.'misman') conv_fact = 1._wp !stop 'Convergence not implemented for misman grid.' !
 parameters%grid%ncells = parameters%grid%ncells * conv_fact
 parameters%output%every_t_step = parameters%output%every_t_step * conv_fact * extra
 parameters%output%every_x_step = parameters%output%every_x_step * conv_fact ! set conv_fact to one here if no automatic convergence form desired (and it will output all points)
 parameters%timer%dt = parameters%timer%dt / conv_fact / extra
 parameters%grid%dx = parameters%grid%dx / conv_fact
!write(*,*) parameters%grid%ncells, parameters%timer%dt
  end do

  call cpu_time(finish)

  write(*,'(a,i2,a,i2,a,f5.2,a)') "Execution time = ", int((finish-start)/3600._wp), " h ", int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp), " m ", dble((finish-start)-int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp)*60)," s "

contains

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! main program
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!


  subroutine main(level)

implicit none

integer, intent(in) :: level
integer, parameter  :: npde = 6, nconstraints = 3
real(kind=wp), dimension(:,:), allocatable :: u, constr
real(kind=wp), dimension(:), allocatable :: x
character :: delvoid*150, ext*4
integer :: ns, centerindex, i, j, l, excindex
real(kind=wp) :: msmasscenter
logical :: dynupdate

real(kind=wp) ::h, k

ext = parameters%output%suffix

ns = 0
if (parameters%grid%origin.eq.'stag') ns = 1
if (parameters%grid%origin.eq.'misman') ns = 0

allocate( u(npde, -parameters%grid%nghost : parameters%grid%ncells -ns + parameters%grid%nghost) )
allocate( constr(nconstraints, -parameters%grid%nghost : parameters%grid%ncells -ns + parameters%grid%nghost) )

call grid_allocate(lbound(u,2), ubound(u, 2))
call new_grid(parameters)

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! set the initial data and the boundary conditions
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

! include 'source.f90'

 call initialdata(u, constr, xp, parameters)
! call setboundaries(u,parameters)

allocate( x(lbound(u,2) : ubound(u, 2)) )

  x = xp

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! evolution and output loop
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

  delvoid = 'echo Deleting output files for void ... & rm '//trim(file_prefix)//'*void*_'//trim(parameters%moldef%deriv_method)//'_*'//trim(ext)//'  &'
  delvoid = trim(delvoid)

  write(*,*) 'CFL = ', parameters%timer%dt/(parameters%grid%xmax-parameters%grid%xmin)*parameters%grid%ncells
!  if (parameters%timer%dt/(parameters%grid%xmax-parameters%grid%xmin)*parameters%grid%ncells.gt.0.5d0) stop 'CFL is larger than 0.5.'

  last_step = ceiling((parameters%timer%end_time - parameters%timer%t) / parameters%timer%dt)
  do i = 0, last_step
 if(modulo(i, parameters%output%every_t_step) == 0) then
 call write_step(level, i, parameters, u, constr, x)!!!!!!!!!!!11
 write(*,'(F12.5)') parameters%timer%t
 end if
call molstep(u, constr, x, parameters)
 parameters%timer%step = i+1

do j=lbound(u,1), ubound(u,1)
	do l=0+1, parameters%grid%ncells-ns-1
		if(isnan(u(j,l))) then
			write(*,*) "Variables have become NaN at x = ", x(l)
if (.true.)	call system(delvoid) ! delete files with variable name "void"
  call cpu_time(finish)
  write(*,'(a,i2,a,i2,a,f5.2,a)') "Execution time = ", int((finish-start)/3600._wp), " h ", int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp), " m ", dble((finish-start)-int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp)*60)," s "
			stop
		endif
	enddo
enddo
 if (maxval(abs(u(:,0:parameters%grid%ncells-ns))) > 1d300) then
	write(*,*) "Crash at", x(maxloc(u))
if (.true.)	call system(delvoid) ! delete files with variable name "void"

  call cpu_time(finish)
  write(*,'(a,i2,a,i2,a,f5.2,a)') "Execution time = ", int((finish-start)/3600._wp), " h ", int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp), " m ", dble((finish-start)-int(((finish-start)-int((finish-start)/3600._wp)*3600)/60._wp)*60)," s "
 stop
 end if

  end do

if (.true.)	call system(delvoid) ! delete files with variable name "void"

  ! Write out the last step of evolution completely to a file
!  if(parameters%id%id_type.ne.'from_data') then

 open(19, FILE=trim(file_prefix)//'last_data.txt', STATUS='REPLACE')
 write(19,*) size(u(1,:)), parameters%timer%t-parameters%timer%dt
! do i=0,parameters%grid%ncells
 do i = lbound(u,2), ubound(u,2)
 write(19,'(16(e35.24e3))') (u(j,i),j=lbound(u,1), ubound(u,1))
 end do
 close(19)
!  end if
! '(3(e35.24e3))'
  call grid_deallocate
  deallocate(u,constr)
  call moldeallocate

end subroutine main

end program  gbssnsphersym

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! The calculation of the rhs
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine calcrhs(u, constr, x, rhs, parameters)
  use parameters_mod
  use numservicef90
  use mol
  implicit none

  real(kind=wp), dimension(:,:), intent(inout):: u ! changed from in to inout on 24-06-2016
  real(kind=wp), dimension(:,:), intent(out):: constr
  real(kind=wp), dimension(:),intent(in):: x
  type(parameters_type),  intent(inout) :: parameters
  real(kind=wp), dimension(size(u,1), size(u,2)), intent(out) :: rhs
!
  real(kind=wp), dimension(size(u,1), size(u,2)) :: du, ddu, u_diss, dru, druin
  real(kind=wp), dimension(size(x)) :: phi, pi, psi, void
  real(kind=wp), dimension(size(x)) :: dphi, dpi, dpsi, dvoid
  real(kind=wp), dimension(size(x)) :: drphi, drpi, drpsi, drvoid ! for offcentered advection terms
  real(kind=wp), dimension(size(x)) :: ddphi, ddpi, ddpsi, ddvoid
  real(kind=wp), dimension(size(x)) :: omega, domega, ddomega, dddomega
  real(kind=wp) :: gamma2, mu, eps, mass, xmax, delta, nindex, xscri, xexc
  real(kind=wp) :: Kcmc, rmatchmin, rmatchmax
  integer	:: last, nro, nr0, counter, numr, advsten, i, imatchmin, imatchmax
  real(kind=wp) :: dx


  integer, parameter :: n2v = 6 !change here, in the parameter file and in subroutines: initialdata, setboundaries

  gamma2 = parameters%physics%gamma2
  mu = parameters%physics%mu
  mass = parameters%physics%mass
  advsten = parameters%physics%advsten
  xmax = parameters%grid%xmax
  xscri = parameters%physics%xscri
  xexc = parameters%physics%xexc
  delta = parameters%physics%delta
  nindex = parameters%physics%nindex
  Kcmc = parameters%physics%Kcmc
  rmatchmin = parameters%slice%rmatchmin
  rmatchmax = parameters%slice%rmatchmax

  eps = parameters%moldef%dissipation_eps

  dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / dble(parameters%grid%ncells)
!  if (parameters%grid%origin.eq.'stag') dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / (dble(parameters%grid%ncells+1)) !change for staggered grid !RUINS CONVERGENCE!!!!!!
  if (parameters%grid%origin.eq.'misman') dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / (dble(parameters%grid%ncells)+0.5_wp)

  omega = -Kcmc*(xscri+x)*(xscri-x)/(6._wp*xscri)
  domega = Kcmc*x/(3._wp*xscri)
  ddomega = Kcmc/(3._wp*xscri)!  dddomega = 0


  include './source.f90'

end subroutine calcrhs
