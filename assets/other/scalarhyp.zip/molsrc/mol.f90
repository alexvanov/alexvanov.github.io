!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! The heart of the module is the subroutine molstep
! it does the time evolution step using method of lines
!
!   statevect = statevect + dt*rhs
!
! The rhs is calculated by the subroutine calcrhs
! calcrhs is where the physical system comes in.
! It will be modified when equations change.
!
! Because of the abstract nature of mol,
! this module doesn't need modification for different systems.
!
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

module mol
  use prec
  use parameters_mod
  use molparameters

  implicit none

    real(kind=wp), dimension(:,:,:), private,   allocatable, save  :: tmp
    real(kind=wp), parameter :: third=1.0_wp/3.0_wp, sixth=1.0_wp/6.0_wp
    integer  :: tmpsteps

contains

  subroutine mol_param_testing(parameters)
    implicit none
    type(parameters_type), intent(in) :: parameters

    if(parameters%timer%dt <= 0.0_wp) then
  stop 'dt smaller than zero!'
    endif

    if(parameters%timer%t > parameters%timer%end_time) then
  stop 'end_time too small!'
    endif
end subroutine mol_param_testing

  subroutine molstep(statevect, constr, gridvect, parameters)

    !use boundaries
    implicit none

    interface
  subroutine calcrhs(statevect, constr, gridvect, rhs, parameters)
use parameters_mod

real(kind=wp), dimension(:,:),intent(in) :: statevect,  constr
real(kind=wp), dimension(:),intent(in) :: gridvect
type(parameters_type), intent(in) :: parameters

real(kind=wp), dimension(size(statevect,1), &
    &size(statevect,2)), intent(out) :: rhs
  end subroutine calcrhs
    end interface


    real(kind=wp), dimension(:,:),intent(inout) :: statevect, constr
    real(kind=wp), dimension(:),intent(inout) :: gridvect

    type(parameters_type), intent(inout) :: parameters

    real(kind=wp), dimension(size(statevect,1), size(statevect,2)) :: rhs

    integer  :: counter = 1 !used in the Adams-Bashford-Moulton method
    integer  :: modul  !used in the Adams-Bashford-Moulton method


    ! executable statements


    select case(parameters%moldef%int_method)

    case ('rk3')
  tmpsteps = 2
    case ('rk4')
  tmpsteps = 2
    case ('rk4_3')
  tmpsteps = 3
    end select


    if (.NOT.(allocated(tmp)) .AND.  (tmpsteps > 0))  then
  allocate(tmp(size(statevect,1), size(statevect,2), tmpsteps))
  print*, 'allocated ', tmpsteps, ' temporary time levels for MoL'
    endif

    select case(parameters%moldef%int_method)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Heun's third-order formula Trefethen 1994 p75
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
    case ('rk3')
! step 1
  call calcrhs(statevect, constr, gridvect, rhs, parameters)
  tmp(:,:,1) = statevect + third * parameters%timer%dt * rhs
  call setboundaries(tmp(:,:,1), gridvect, parameters)

  parameters%timer%t = parameters%timer%t + third*parameters%timer%dt

! step 2
  call calcrhs(tmp(:,:,1), constr, gridvect, rhs, parameters)
  tmp(:,:,2) = statevect + 2._wp * third * parameters%timer%dt * rhs
  call setboundaries(tmp(:,:,2), gridvect, parameters)

  parameters%timer%t = parameters%timer%t + third*parameters%timer%dt

! step 3
  call calcrhs(tmp(:,:,2), constr, gridvect, rhs, parameters)

  statevect = 0.25_wp*(statevect + 3._wp*(tmp(:,:,1)+ parameters%timer%dt * rhs))
  call setboundaries(statevect, gridvect, parameters)

  parameters%timer%t = parameters%timer%t + third*parameters%timer%dt


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! This seems to be a correct implementation of rk4 Trefethen 1994 p 76
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    case ('rk4_3')  ! rk4 with _3_ timelevels

! step 1
  call calcrhs(statevect, constr, gridvect, rhs, parameters)
  tmp(:,:, 1) = statevect + rhs * parameters%timer%dt * 0.5_wp
  call setboundaries(tmp(:,:,1), gridvect, parameters)
  parameters%timer%t = parameters%timer%t + parameters%timer%dt *0.5_wp

  tmp(:,:, 3) = rhs

! step 2
  call calcrhs(tmp(:,:, 1), constr, gridvect, rhs, parameters)
  tmp(:,:, 2) = statevect + rhs * parameters%timer%dt * 0.5_wp
  call setboundaries( tmp(:,:, 2), gridvect, parameters)

  tmp(:,:, 3) =  tmp(:,:, 3) + 2.0_wp * rhs

! step 3
  call calcrhs(tmp(:,:, 2), constr, gridvect, rhs, parameters)

  tmp(:,:, 1) = statevect  + rhs * parameters%timer%dt
  call setboundaries(tmp(:,:, 1), gridvect, parameters)
  parameters%timer%t = parameters%timer%t + parameters%timer%dt *0.5_wp

  tmp(:,:, 3) =  tmp(:,:, 3) + 2.0_wp * rhs

! step 4
  call calcrhs(tmp(:,:, 1), constr, gridvect, rhs, parameters)

  tmp(:,:, 3) =  tmp(:,:, 3) + rhs

  statevect = statevect + parameters%timer%dt*sixth *  tmp(:,:, 3)
  call setboundaries(statevect, gridvect, parameters)


!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!    RK4
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    case ('rk4')  ! rk4 with 2 timelevels

  stop 'rk4 is not correctly implemented.'

! step 1
  call calcrhs(statevect, constr, gridvect, rhs, parameters)
  tmp(:,:, 1) = statevect + rhs * parameters%timer%dt * 0.5_wp
  call setboundaries(tmp(:,:,1), gridvect, parameters)
  parameters%timer%t = parameters%timer%t + parameters%timer%dt *0.5_wp

  statevect = statevect + (parameters%timer%dt *sixth) * rhs

! step 2

  call calcrhs(tmp(:,:, 1), constr, gridvect, rhs, parameters)

  tmp(:,:, 2) = statevect  + rhs * parameters%timer%dt * 0.5_wp
  call setboundaries(statevect, gridvect, parameters)
  statevect = statevect + (parameters%timer%dt / 3.0_wp) * rhs

! step 3
  call calcrhs(tmp(:,:, 2), constr, gridvect, rhs, parameters)

  tmp(:,:, 1) = statevect  + rhs * parameters%timer%dt
  call setboundaries(statevect, gridvect, parameters)
  parameters%timer%t = parameters%timer%t + parameters%timer%dt *0.5_wp

  statevect = statevect + (parameters%timer%dt / 3.0_wp) * rhs

! step 4
  call calcrhs(tmp(:,:, 1), constr, gridvect, rhs, parameters)

  statevect = statevect  + parameters%timer%dt / (6.0_wp) * rhs
  call setboundaries(statevect, gridvect, parameters)


    case DEFAULT
  stop 'method not supported'

    end select
  end subroutine molstep



!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
! Setting initial data
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

subroutine initialdata(u, constr, xv, parameters)
!  use parameters_mod
  use numservicef90
  implicit none

  real(kind=wp), dimension(:,:), intent(inout) :: u
  real(kind=wp), dimension(:,:),intent(out)    :: constr
  real(kind=iwp), dimension(:),   intent(inout)  :: xv
  real(kind=wp), dimension(size(xv)) :: rh
  real(kind=wp), dimension(size(xv)) :: x
  type(parameters_type),intent(inout)  :: parameters

  character :: cc*5,ac*5

  real(kind=wp) :: a, sigma, center!, v, h, k
  integer :: i, j, n, noise


  real(kind=wp), dimension(size(u,1), size(u,2)) :: rhs
!
  real(kind=wp), dimension(size(u,1), size(u,2)) :: du, ddu, u_diss, dru, druin
  real(kind=wp), dimension(size(x)) :: phi, pi, psi, void
  real(kind=wp), dimension(size(x)) :: dphi, dpi, dpsi, dvoid
  real(kind=wp), dimension(size(x)) :: drphi, drpi, drpsi, drvoid ! for offcentered advection terms
  real(kind=wp), dimension(size(x)) :: ddphi, ddpi, ddpsi, ddvoid
  real(kind=wp), dimension(size(x)) :: omega, domega, ddomega, dddomega
  real(kind=wp) :: Kcmc, propsign, rmatchmin, rmatchmax
  integer	:: last, nro, nr0, counter, numr, advsten, imatchmin, imatchmax
  real(kind=wp) :: dx, eps, mu, gamma2, delta, nindex, xscri, xexc, mass
!!
  integer :: nt
  real(kind=wp) :: dt = 0.000001, rms = 1, rms0 = 0
  integer :: lb, ub, li, ui

  integer, parameter :: n2v = 6

  x = xv

    ! executable statements

    lb = lbound(u, 2)
    ub = ubound(u, 2)

    li = lb + parameters%grid%nghost
    ui = ub - parameters%grid%nghost

  gamma2 = parameters%physics%gamma2
  mu = parameters%physics%mu
  mass = parameters%physics%mass
  advsten = parameters%physics%advsten
  xscri = parameters%physics%xscri
  xexc = parameters%physics%xexc
  delta = parameters%physics%delta
  nindex = parameters%physics%nindex
  Kcmc = parameters%physics%Kcmc
  propsign = parameters%physics%propsign
  rmatchmin = parameters%slice%rmatchmin
  rmatchmax = parameters%slice%rmatchmax

  eps = parameters%moldef%dissipation_eps
!
dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / dble(parameters%grid%ncells)
!if (parameters%grid%origin.eq.'stag') dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / (dble(parameters%grid%ncells+1)) !change for staggered grid  !RUINS CONVERGENCE!!!!!!!
if (parameters%grid%origin.eq.'misman') then
	dx   = abs(parameters%grid%xmax - parameters%grid%xmin) / (dble(parameters%grid%ncells)+0.5_wp)
endif

  ! Just for the convenience and readibility

  omega = -Kcmc*(xscri+x)*(xscri-x)/(6._wp*xscri)
  domega = Kcmc*x/(3._wp*xscri)
  ddomega = Kcmc/(3._wp*xscri)!  dddomega = 0

  a = parameters%id%a
  sigma = parameters%id%sigma
  center = parameters%id%center

  noise = parameters%id%noise

!! initial data is set here, in the chosen option from below

  select case(parameters%id%id_type)

  case ('from_data')

open(13, FILE=trim(file_prefix)//'last_data.txt', STATUS='OLD')
read(13,*) n, parameters%timer%t
parameters%timer%end_time = parameters%timer%end_time + parameters%timer%t
if(n.ne.size(u(1,:))) then !parameters%grid%ncells+1
write(*,*) n
stop "wrong number of data points"
end if
write(*,*) parameters%grid%ncells+1-n,size(u(1,:))-n
!do i= 1, parameters%grid%ncells+1
do i = lbound(u,2), ubound(u,2)
read(13,'(16(e35.24e3))') (u(j,i),j=lbound(u,1), ubound(u,1))
!	read (13,*) (u(j,i),j=1,n)
enddo
close(13)


   case ('gaussian')

call random_number(u)
u = (u - 0.5_wp)*1.0d-8 !0.1_wp

u(1,:) = noise*u(1,:) + (a*exp(-(x**2-center**2)**2/(4._wp*sigma**4)))/omega

u(2,:) =  -(-a*exp(-(x**2-center**2)**2/(4._wp*sigma**4))*x*(x**2-center**2)/sigma**4) * ( Kcmc*x/3._iwp )*(-propsign-1)/omega ! for rescaled pi (pphi=0)

 if (parameters%grid%origin.eq.'nostag') then !setting to zero initial value of the scalar field variables at scri: necessary when the rescaled variables are used
 print*, 'Warning: setting central value of pi manually.' ! in the following line
 u(2,li) = -(-a*exp(-(x(li)**2-center**2)**2/(4._wp*sigma**4))*x(li)*(x(li)**2-center**2)/sigma**4) * ( Kcmc*x(li)/3._iwp )*(-propsign-1)/omega(li) ! for rescaled pi (pphi=0)
 u(1,ui) = 0
 u(2,ui) = 0
 endif

if (parameters%grid%origin.eq.'misman') then !setting to zero initial value of the scalar field variables at scri: necessary when the rescaled variables are used
 u(1,ui) = 0
 u(2,ui) = 0
 endif

include '../source.f90' ! to calculate the constraints

   case ('bump') ! amplitude is very small, increase!!
!if(.false.)then ! Pune, 07-11-2017
!print*, 'Tests for massive wave equation (IUCAA, Pune): compact support bump in phi.'
  imatchmin = minloc(abs(x-rmatchmin),1)
  imatchmax = minloc(abs(x-rmatchmax),1)
 u(1,imatchmin:imatchmax) = a*exp(-sigma*(1/(x(imatchmin:imatchmax)-rmatchmin)**2+1/(x(imatchmin:imatchmax)-rmatchmax)**2))
 u(2,imatchmin:imatchmax) = -(a*exp(-sigma*(1/(x(imatchmin:imatchmax)-rmatchmin)**2+1/(x(imatchmin:imatchmax)-rmatchmax)**2))*sigma*2*(1/(x(imatchmin:imatchmax)-rmatchmin)**3+1/(x(imatchmin:imatchmax)-rmatchmax)**3)) * ( Kcmc*x(imatchmin:imatchmax)/3._iwp )*(-propsign-1)/omega(imatchmin:imatchmax) !(-propsign/psi(imatchmin:imatchmax)**6-1)
 u(1,li:imatchmin) = 0
 u(2,li:imatchmin) = 0
 u(1,imatchmax:ui) = 0
 u(2,imatchmax:ui) = 0
! Pune, 07-11-2017
!endif


include '../source.f90' ! to calculate the constraints

   case('ern')
   u=0
   u(1,:) = (a*exp(-(x**2-center**2)**2/(4._wp*sigma**4)))
   u(2,:) = 0

include '../source.f90' ! to calculate the constraints


  case ('from_data_perturb')

open(13, FILE=trim(file_prefix)//'last_data.txt', STATUS='OLD')
read(13,*) n, parameters%timer%t
parameters%timer%end_time = parameters%timer%end_time + parameters%timer%t
if(n.ne.size(u(1,:))) then !parameters%grid%ncells+1
write(*,*) n
stop "wrong number of data points"
end if
write(*,*) parameters%grid%ncells+1-n,size(u(1,:))-n
!do i= 1, parameters%grid%ncells+1
do i = lbound(u,2), ubound(u,2)
read(13,'(16(e35.24e3))') (u(j,i),j=lbound(u,1), ubound(u,1))
!	read (13,*) (u(j,i),j=1,n)
enddo
close(13)



   case default

stop 'No initial data specified.'

   end select

end subroutine initialdata


subroutine setboundaries(vect, x, parameters)
  use numservicef90
  implicit none

    real(kind=wp), dimension(:,:),intent(inout) :: vect
    real(kind=wp), dimension(:),intent(inout) :: x
    type(parameters_type), intent(in)    :: parameters

  real(kind=wp), dimension(size(x)) :: omega, domega, ddomega, dddomega
  integer :: lb, ub, li, ui, counter

    ! executable statements

    lb = lbound(vect, 2)
    ub = ubound(vect, 2)

    li = lb + parameters%grid%nghost
    ui = ub - parameters%grid%nghost

!    dx = abs(parameters%grid%xmax - parameters%grid%xmin) / dble(parameters%grid%ncells)

    select case (parameters%moldef%boundary_type)

!bc
    case ('zero')
  ! From li to lb and from ui to ub because
  ! ui + li - lb = ub - nghost + lb + nghost - lb = ub
  ! That sets also the ghost points to zero.
  do counter = 0, li - lb
vect(:, li-counter) = 0.0_wp
vect(:, ui+counter) = 0.0_wp
  end do

!bc
    case ('periodic')
  do counter = 0, abs(parameters%grid%nghost)
vect(:, ui + counter) = vect(:, li + counter)
vect(:, li - counter) = vect(:, ui - counter)
  enddo

!bc
    case ('reflecting')
  vect(1, lb) = 0.0_wp
  vect(1, ub) = 0.0_wp

  vect(2, lb) = vect(2, li)
  vect(2, ub) = vect(2, ui)

  vect(3, lb) = 0.0_wp
  vect(3, ub) = 0.0_wp

!bc
    case('sommerfeld')
  vect(2, li) =   vect(1, li)
  vect(2, ui) = - vect(1, ui)

!bc
    case('compact')
  ! Inner boundary at the center
  vect(2, li) = 0d0

!bc
    case('spherical_hyperal')
  ! Inner boundary at the center
  vect(2, li) = 0d0
  ! Outgoing at the outer boundary
  vect(2, ui) = - vect(1, ui) - vect(3,ui)!/parameters%grid%xmax

!bc
    case('spherical')
  ! Inner boundary at the center
  vect(2, li) = 0d0

  ! Set the ingoing characteristic to zero at the outer boundary
  vect(2, ui) = - vect(1, ui) - vect(3,ui)/parameters%grid%xmax  !psi = -pi - phi

!bc
    case('4waver')
	do counter = 1, abs(parameters%grid%nghost)
  		vect(1, lb + counter - 1) = + vect(1, li + abs(parameters%grid%nghost) - counter) ! +
  	    	!vect(1, ub - counter + 1) = 0.0_wp
	   	!vect(2, lb + counter - 1) = - vect(2, li + abs(parameters%grid%nghost) - counter) ! -
   	 	!vect(2, ub - counter + 1) = 0.0_wp
  		vect(2, lb + counter - 1) = + vect(2, li + abs(parameters%grid%nghost) - counter) ! +
	 	!vect(3, ub - counter + 1) = 0.0_wp
		!vect(1,ub - counter + 1) = 0.0_wp
		!vect(2,ub - counter + 1) = vect(1,ub - counter + 1)
	enddo
	!vect(2, ui) = - vect(1, ui) - vect(3,ui)!/parameters%grid%xmax

!bc
    case('gbssn')

    !Non-staggered grid
    if (parameters%grid%origin.eq.'nostag') then

	! at xmin
	select case (parameters%moldef%deriv_method)
	   case ('c2')
  		vect(:, li) = (4.0_wp*vect(:, li+1) - vect(:, li+2))/3.0_wp ! even at the origin
  		vect(3, li) = 0.0_wp ! odd at the origin
	   case ('c4')
  		vect(:, li) = (48._wp*vect(:,li+1) - 36._wp*vect(:,li+2) + 16._wp*vect(:,li+3) - 3._wp*vect(:,li+4))/25.0_wp
  		vect(3, li) = 0.0_wp
	   case ('c6')
  		vect(:, li) = (360._wp*vect(:,li+1) - 450._wp*vect(:,li+2) + 400._wp*vect(:,li+3) - 225._wp*vect(:,li+4) + 72._wp*vect(:,li+5) - 10._wp*vect(:,li+6))/147.0_wp
  		vect(3, li) = 0.0_wp
	   case ('c8')
  		vect(:, li) = (6720._wp*vect(:,li+1) - 11760._wp*vect(:,li+2) + 15680._wp*vect(:,li+3) - 14700._wp*vect(:,li+4) + 9408._wp*vect(:,li+5) - 3920._wp*vect(:,li+6) + 960._wp*vect(:,li+7) - 105._wp*vect(:,li+8))/2283.0_wp
  		vect(3, li) = 0.0_wp
	end select
	do counter = 1, abs(parameters%grid%nghost)
  		vect(:, lb + counter - 1) = + vect(:, li + abs(parameters%grid%nghost) - counter + 1)
  		vect(3, lb + counter - 1) = - vect(3, li + abs(parameters%grid%nghost) - counter + 1)
	enddo

! overflow boundary of 0509119
	! at xmax
	select case (parameters%grid%nghost)

	   case(1)
		!Variables derived only once - (hD_-)^2
  		vect(:, ub-0) = 2*vect(:, ui-0)-vect(:, ui-1)
 		  vect(:, ub-0) = 3*vect(:, ui-0)-3*vect(:, ui-1)+vect(:, ui-2) ! apparently very similar
		!Variables derived twice - (hD_-)^3
  		vect(1, ub-0) = 3*vect(1, ui-0)-3*vect(1, ui-1)+vect(1, ui-2)

	   case(2)
		!Variables derived only once - (hD_-)^4
  		vect(:, ub-1) = 4*vect(:, ui-0)-6*vect(:, ui-1)+4*vect(:, ui-2)-vect(:, ui-3)
  		vect(:, ub-0) = 4*vect(:, ui+1)-6*vect(:, ui-0)+4*vect(:, ui-1)-vect(:, ui-2)
 		  vect(:, ub-1) = 5*vect(:, ui-0)-10*vect(:, ui-1)+10*vect(:, ui-2)-5*vect(:, ui-3)+vect(:, ui-4) ! apparently very similar
 		  vect(:, ub-0) = 5*vect(:, ui+1)-10*vect(:, ui-0)+10*vect(:, ui-1)-5*vect(:, ui-2)+vect(:, ui-3) ! apparently very similar
		!Variables derived twice - (hD_-)^5
  		vect(1, ub-1) = 5*vect(1, ui-0)-10*vect(1, ui-1)+10*vect(1, ui-2)-5*vect(1, ui-3)+vect(1, ui-4)
  		vect(1, ub-0) = 5*vect(1, ui+1)-10*vect(1, ui-0)+10*vect(1, ui-1)-5*vect(1, ui-2)+vect(1, ui-3)
	   case(3)
		!Variables derived only once - (hD_-)^6
  		vect(:, ub-2) = - vect(:,-5 + ui) + 6*vect(:,-4 + ui) - 15*vect(:,-3 + ui) + 20*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 6*vect(:,ui)
  		vect(:, ub-1) = - vect(:,-4 + ui) + 6*vect(:,-3 + ui) - 15*vect(:,-2 + ui) + 20*vect(:,-1 + ui) - 15*vect(:,ui) + 6*vect(:,1 + ui)
  		vect(:, ub-0) = - vect(:,-3 + ui) + 6*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 20*vect(:,ui) - 15*vect(:,1 + ui) + 6*vect(:,2 + ui)
		!Variables derived twice - (hD_-)^7
		  vect(1, ub-2) = vect(1,-6 + ui) - 7*vect(1,-5 + ui) + 21*vect(1,-4 + ui) - 35*vect(1,-3 + ui) + 35*vect(1,-2 + ui) - 21*vect(1,-1 + ui) + 7*vect(1,ui)
  		vect(1, ub-1) = vect(1,-5 + ui) - 7*vect(1,-4 + ui) + 21*vect(1,-3 + ui) - 35*vect(1,-2 + ui) + 35*vect(1,-1 + ui) - 21*vect(1,ui) + 7*vect(1,1 + ui)
  		vect(1, ub-0) = vect(1,-4 + ui) - 7*vect(1,-3 + ui) + 21*vect(1,-2 + ui) - 35*vect(1,-1 + ui) + 35*vect(1,ui) - 21*vect(1,1 + ui) + 7*vect(1,2 + ui)

	   case(4)
		!Variables derived only once - (hD_-)^8
  		vect(:, ub-3) = -vect(:,-7+ui)+8*vect(:,-6+ui) - 28*vect(:,-5+ui)+56*vect(:,-4+ui) - 70*vect(:,-3+ui)+56*vect(:,-2+ui) - 28*vect(:,-1+ui)+8*vect(:,ui)
  		vect(:, ub-2) = -vect(:,-6+ui)+8*vect(:,-5+ui) - 28*vect(:,-4+ui)+56*vect(:,-3+ui) - 70*vect(:,-2+ui)+56*vect(:,-1+ui) - 28*vect(:,ui)+8*vect(:,1+ui)
  		vect(:, ub-1) = -vect(:,-5+ui)+8*vect(:,-4+ui) - 28*vect(:,-3+ui)+56*vect(:,-2+ui) - 70*vect(:,-1+ui)+56*vect(:,ui) - 28*vect(:,1+ui)+8*vect(:,2+ui)
  		vect(:, ub-0) = -vect(:,-4+ui)+8*vect(:,-3+ui) - 28*vect(:,-2+ui)+56*vect(:,-1+ui) - 70*vect(:,ui)+56*vect(:,1+ui) - 28*vect(:,2+ui)+8*vect(:,3+ui)
		!Variables derived twice - (hD_-)^9
		vect(1,ub-3) = vect(1,-8+ui) - 9*vect(1,-7+ui)+36*vect(1,-6+ui) - 84*vect(1,-5+ui)+126*vect(1,-4+ui) - 126*vect(1,-3+ui)+84*vect(1,-2+ui) - 36*vect(1,-1+ui)+9*vect(1,ui)
		vect(1,ub-2) = vect(1,-7+ui) - 9*vect(1,-6+ui)+36*vect(1,-5+ui) - 84*vect(1,-4+ui)+126*vect(1,-3+ui) - 126*vect(1,-2+ui)+84*vect(1,-1+ui) - 36*vect(1,ui)+9*vect(1,1+ui)
		vect(1,ub-1) = vect(1,-6+ui) - 9*vect(1,-5+ui)+36*vect(1,-4+ui) - 84*vect(1,-3+ui)+126*vect(1,-2+ui) - 126*vect(1,-1+ui)+84*vect(1,ui) - 36*vect(1,1+ui)+9*vect(1,2+ui)
		vect(1,ub-0) = vect(1,-5+ui) - 9*vect(1,-4+ui)+36*vect(1,-3+ui) - 84*vect(1,-2+ui)+126*vect(1,-1+ui) - 126*vect(1,ui)+84*vect(1,1+ui) - 36*vect(1,2+ui)+9*vect(1,3+ui)

	end select


    elseif (parameters%grid%origin.eq.'stag') then
!!excision at inner boundary ! also change down
if(.false.) then
	do counter = 1, abs(parameters%grid%nghost)
  		vect(:, lb + counter - 1) = + vect(:, li + abs(parameters%grid%nghost) - counter)
  		vect(3, lb + counter - 1) = - vect(3, li + abs(parameters%grid%nghost) - counter)
	enddo
endif

! overflow boundary of 0509119
	! at xmax
	select case (parameters%grid%nghost)

	   case(1)
		!Variables derived only once - (hD_-)^2
  		vect(:, ub-0) = 2*vect(:, ui-0)-vect(:, ui-1)
 		  vect(:, ub-0) = 3*vect(:, ui-0)-3*vect(:, ui-1)+vect(:, ui-2) ! apparently very similar
		!Variables derived twice - (hD_-)^3
  		vect(1, ub-0) = 3*vect(1, ui-0)-3*vect(1, ui-1)+vect(1, ui-2)

	   case(2)
		!Variables derived only once - (hD_-)^4
		  vect(:, ub-1) = 4*vect(:, ui-0)-6*vect(:, ui-1)+4*vect(:, ui-2)-vect(:, ui-3)
  		vect(:, ub-0) = 4*vect(:, ui+1)-6*vect(:, ui-0)+4*vect(:, ui-1)-vect(:, ui-2)
 		  vect(:, ub-1) = 5*vect(:, ui-0)-10*vect(:, ui-1)+10*vect(:, ui-2)-5*vect(:, ui-3)+vect(:, ui-4) ! apparently very similar
 		  vect(:, ub-0) = 5*vect(:, ui+1)-10*vect(:, ui-0)+10*vect(:, ui-1)-5*vect(:, ui-2)+vect(:, ui-3) ! apparently very similar
		!Variables derived twice - (hD_-)^5
  		vect(1, ub-1) = 5*vect(1, ui-0)-10*vect(1, ui-1)+10*vect(1, ui-2)-5*vect(1, ui-3)+vect(1, ui-4)
  		vect(1, ub-0) = 5*vect(1, ui+1)-10*vect(1, ui-0)+10*vect(1, ui-1)-5*vect(1, ui-2)+vect(1, ui-3)


!!excision at inner boundary ! also change up and in 4th order dissipation in numservice
if(.true.)then
	vect(:, lb+1) = 4*vect(:, li+0)-6*vect(:, li+1)+4*vect(:, li+2)-vect(:, li+3)
  		vect(:, lb+0) = 4*vect(:, li-1)-6*vect(:, li+0)+4*vect(:, li+1)-vect(:, li+2)
  		vect(1, lb+1) = 5*vect(1, li+0)-10*vect(1, li+1)+10*vect(1, li+2)-5*vect(1, li+3)+vect(1, li+4)
  		vect(1, lb+0) = 5*vect(1, li-1)-10*vect(1, li+0)+10*vect(1, li+1)-5*vect(1, li+2)+vect(1, li+3)
endif

!	   case ('c6')
	   case(3)
		!Variables derived only once - (hD_-)^6
  		vect(:, ub-2) = - vect(:,-5 + ui) + 6*vect(:,-4 + ui) - 15*vect(:,-3 + ui) + 20*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 6*vect(:,ui)
  		vect(:, ub-1) = - vect(:,-4 + ui) + 6*vect(:,-3 + ui) - 15*vect(:,-2 + ui) + 20*vect(:,-1 + ui) - 15*vect(:,ui) + 6*vect(:,1 + ui)
  		vect(:, ub-0) = - vect(:,-3 + ui) + 6*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 20*vect(:,ui) - 15*vect(:,1 + ui) + 6*vect(:,2 + ui)
		!Variables derived twice - (hD_-)^7
		  vect(1, ub-2) = vect(1,-6 + ui) - 7*vect(1,-5 + ui) + 21*vect(1,-4 + ui) - 35*vect(1,-3 + ui) + 35*vect(1,-2 + ui) - 21*vect(1,-1 + ui) + 7*vect(1,ui)
  		vect(1, ub-1) = vect(1,-5 + ui) - 7*vect(1,-4 + ui) + 21*vect(1,-3 + ui) - 35*vect(1,-2 + ui) + 35*vect(1,-1 + ui) - 21*vect(1,ui) + 7*vect(1,1 + ui)
  		vect(1, ub-0) = vect(1,-4 + ui) - 7*vect(1,-3 + ui) + 21*vect(1,-2 + ui) - 35*vect(1,-1 + ui) + 35*vect(1,ui) - 21*vect(1,1 + ui) + 7*vect(1,2 + ui)

!	   case ('c8')
	   case(4)
!stop 'Wrong conditions at the outer boundary!'
		!Variables derived only once - (hD_-)^8
  		vect(:, ub-3) = -vect(:,-7+ui)+8*vect(:,-6+ui) - 28*vect(:,-5+ui)+56*vect(:,-4+ui) - 70*vect(:,-3+ui)+56*vect(:,-2+ui) - 28*vect(:,-1+ui)+8*vect(:,ui)
  		vect(:, ub-2) = -vect(:,-6+ui)+8*vect(:,-5+ui) - 28*vect(:,-4+ui)+56*vect(:,-3+ui) - 70*vect(:,-2+ui)+56*vect(:,-1+ui) - 28*vect(:,ui)+8*vect(:,1+ui)
  		vect(:, ub-1) = -vect(:,-5+ui)+8*vect(:,-4+ui) - 28*vect(:,-3+ui)+56*vect(:,-2+ui) - 70*vect(:,-1+ui)+56*vect(:,ui) - 28*vect(:,1+ui)+8*vect(:,2+ui)
  		vect(:, ub-0) = -vect(:,-4+ui)+8*vect(:,-3+ui) - 28*vect(:,-2+ui)+56*vect(:,-1+ui) - 70*vect(:,ui)+56*vect(:,1+ui) - 28*vect(:,2+ui)+8*vect(:,3+ui)
		!Variables derived twice - (hD_-)^9
		vect(1,ub-3) = vect(1,-8+ui) - 9*vect(1,-7+ui)+36*vect(1,-6+ui) - 84*vect(1,-5+ui)+126*vect(1,-4+ui) - 126*vect(1,-3+ui)+84*vect(1,-2+ui) - 36*vect(1,-1+ui)+9*vect(1,ui)
		vect(1,ub-2) = vect(1,-7+ui) - 9*vect(1,-6+ui)+36*vect(1,-5+ui) - 84*vect(1,-4+ui)+126*vect(1,-3+ui) - 126*vect(1,-2+ui)+84*vect(1,-1+ui) - 36*vect(1,ui)+9*vect(1,1+ui)
		vect(1,ub-1) = vect(1,-6+ui) - 9*vect(1,-5+ui)+36*vect(1,-4+ui) - 84*vect(1,-3+ui)+126*vect(1,-2+ui) - 126*vect(1,-1+ui)+84*vect(1,ui) - 36*vect(1,1+ui)+9*vect(1,2+ui)
		vect(1,ub-0) = vect(1,-5+ui) - 9*vect(1,-4+ui)+36*vect(1,-3+ui) - 84*vect(1,-2+ui)+126*vect(1,-1+ui) - 126*vect(1,ui)+84*vect(1,1+ui) - 36*vect(1,2+ui)+9*vect(1,3+ui)
	end select

    elseif (parameters%grid%origin.eq.'misman') then
!!excision at inner boundary ! also change down
if(.false.) then
	do counter = 1, abs(parameters%grid%nghost)
  		vect(:, lb + counter - 1) = + vect(:, li + abs(parameters%grid%nghost) - counter)
  		vect(3, lb + counter - 1) = - vect(3, li + abs(parameters%grid%nghost) - counter)
	enddo
endif


! overflow boundary of 0509119
	! at xmax
	select case (parameters%grid%nghost)

	   case(1)
		!Variables derived only once - (hD_-)^2
  		vect(:, ub-0) = 2*vect(:, ui-0)-vect(:, ui-1)
 		  vect(:, ub-0) = 3*vect(:, ui-0)-3*vect(:, ui-1)+vect(:, ui-2) ! apparently very similar
		!Variables derived twice - (hD_-)^3
  		vect(1, ub-0) = 3*vect(1, ui-0)-3*vect(1, ui-1)+vect(1, ui-2)

	   case(2)
		!Variables derived only once - (hD_-)^4
  		vect(:, ub-1) = 4*vect(:, ui-0)-6*vect(:, ui-1)+4*vect(:, ui-2)-vect(:, ui-3)
  		vect(:, ub-0) = 4*vect(:, ui+1)-6*vect(:, ui-0)+4*vect(:, ui-1)-vect(:, ui-2)
 		  vect(:, ub-1) = 5*vect(:, ui-0)-10*vect(:, ui-1)+10*vect(:, ui-2)-5*vect(:, ui-3)+vect(:, ui-4) ! apparently very similar
 		  vect(:, ub-0) = 5*vect(:, ui+1)-10*vect(:, ui-0)+10*vect(:, ui-1)-5*vect(:, ui-2)+vect(:, ui-3) ! apparently very similar
		!Variables derived twice - (hD_-)^5
  		vect(1, ub-1) = 5*vect(1, ui-0)-10*vect(1, ui-1)+10*vect(1, ui-2)-5*vect(1, ui-3)+vect(1, ui-4)
  		vect(1, ub-0) = 5*vect(1, ui+1)-10*vect(1, ui-0)+10*vect(1, ui-1)-5*vect(1, ui-2)+vect(1, ui-3)

!!excision at inner boundary ! also change up and in 4th order dissipation in numservice
if(.true.)then
	    vect(:, lb+1) = 4*vect(:, li+0)-6*vect(:, li+1)+4*vect(:, li+2)-vect(:, li+3)
  		vect(:, lb+0) = 4*vect(:, li-1)-6*vect(:, li+0)+4*vect(:, li+1)-vect(:, li+2)
  		vect(1, lb+1) = 5*vect(1, li+0)-10*vect(1, li+1)+10*vect(1, li+2)-5*vect(1, li+3)+vect(1, li+4)
  		vect(1, lb+0) = 5*vect(1, li-1)-10*vect(1, li+0)+10*vect(1, li+1)-5*vect(1, li+2)+vect(1, li+3)
endif

	   case(3)
		!Variables derived only once - (hD_-)^6
  		vect(:, ub-2) = - vect(:,-5 + ui) + 6*vect(:,-4 + ui) - 15*vect(:,-3 + ui) + 20*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 6*vect(:,ui)
  		vect(:, ub-1) = - vect(:,-4 + ui) + 6*vect(:,-3 + ui) - 15*vect(:,-2 + ui) + 20*vect(:,-1 + ui) - 15*vect(:,ui) + 6*vect(:,1 + ui)
  		vect(:, ub-0) = - vect(:,-3 + ui) + 6*vect(:,-2 + ui) - 15*vect(:,-1 + ui) + 20*vect(:,ui) - 15*vect(:,1 + ui) + 6*vect(:,2 + ui)
		!Variables derived twice - (hD_-)^7
		  vect(1, ub-2) = vect(1,-6 + ui) - 7*vect(1,-5 + ui) + 21*vect(1,-4 + ui) - 35*vect(1,-3 + ui) + 35*vect(1,-2 + ui) - 21*vect(1,-1 + ui) + 7*vect(1,ui)
  		vect(1, ub-1) = vect(1,-5 + ui) - 7*vect(1,-4 + ui) + 21*vect(1,-3 + ui) - 35*vect(1,-2 + ui) + 35*vect(1,-1 + ui) - 21*vect(1,ui) + 7*vect(1,1 + ui)
  		vect(1, ub-0) = vect(1,-4 + ui) - 7*vect(1,-3 + ui) + 21*vect(1,-2 + ui) - 35*vect(1,-1 + ui) + 35*vect(1,ui) - 21*vect(1,1 + ui) + 7*vect(1,2 + ui)

	   case(4)
		!Variables derived only once - (hD_-)^8
  		vect(:, ub-3) = -vect(:,-7+ui)+8*vect(:,-6+ui) - 28*vect(:,-5+ui)+56*vect(:,-4+ui) - 70*vect(:,-3+ui)+56*vect(:,-2+ui) - 28*vect(:,-1+ui)+8*vect(:,ui)
  		vect(:, ub-2) = -vect(:,-6+ui)+8*vect(:,-5+ui) - 28*vect(:,-4+ui)+56*vect(:,-3+ui) - 70*vect(:,-2+ui)+56*vect(:,-1+ui) - 28*vect(:,ui)+8*vect(:,1+ui)
  		vect(:, ub-1) = -vect(:,-5+ui)+8*vect(:,-4+ui) - 28*vect(:,-3+ui)+56*vect(:,-2+ui) - 70*vect(:,-1+ui)+56*vect(:,ui) - 28*vect(:,1+ui)+8*vect(:,2+ui)
  		vect(:, ub-0) = -vect(:,-4+ui)+8*vect(:,-3+ui) - 28*vect(:,-2+ui)+56*vect(:,-1+ui) - 70*vect(:,ui)+56*vect(:,1+ui) - 28*vect(:,2+ui)+8*vect(:,3+ui)
		!Variables derived twice - (hD_-)^9
		vect(1,ub-3) = vect(1,-8+ui) - 9*vect(1,-7+ui)+36*vect(1,-6+ui) - 84*vect(1,-5+ui)+126*vect(1,-4+ui) - 126*vect(1,-3+ui)+84*vect(1,-2+ui) - 36*vect(1,-1+ui)+9*vect(1,ui)
		vect(1,ub-2) = vect(1,-7+ui) - 9*vect(1,-6+ui)+36*vect(1,-5+ui) - 84*vect(1,-4+ui)+126*vect(1,-3+ui) - 126*vect(1,-2+ui)+84*vect(1,-1+ui) - 36*vect(1,ui)+9*vect(1,1+ui)
		vect(1,ub-1) = vect(1,-6+ui) - 9*vect(1,-5+ui)+36*vect(1,-4+ui) - 84*vect(1,-3+ui)+126*vect(1,-2+ui) - 126*vect(1,-1+ui)+84*vect(1,ui) - 36*vect(1,1+ui)+9*vect(1,2+ui)
		vect(1,ub-0) = vect(1,-5+ui) - 9*vect(1,-4+ui)+36*vect(1,-3+ui) - 84*vect(1,-2+ui)+126*vect(1,-1+ui) - 126*vect(1,ui)+84*vect(1,1+ui) - 36*vect(1,2+ui)+9*vect(1,3+ui)
	end select


    else
	stop 'Is the grid staggered or not?'
	!continue
    end if

!bc
    case ('none')
  continue

!bc
    case DEFAULT
  STOP 'boundary condition unknown'

    end select
  end subroutine setboundaries



  subroutine moldeallocate
    if(tmpsteps>0) deallocate(tmp)
  end subroutine moldeallocate


end module mol
