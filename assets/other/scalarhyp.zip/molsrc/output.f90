module output

  use prec
  use parameters_mod
  use molparameters

  implicit none

contains

 subroutine outputparam_testing(parameters)
    implicit none

    type(parameters_type), intent(inout) :: parameters

    if(parameters%output%every_t_step <= 0) then
       parameters%output%every_t_step = 1
    endif

    if(parameters%output%every_x_step <= 0) then
       parameters%output%every_x_step = 1
    endif
  end subroutine outputparam_testing

  subroutine set_default_output_parameters
    implicit none

    default_parameters%output%every_t_step = 1
    default_parameters%output%every_x_step = 1
    default_parameters%output%suffix       = '.yg' !for pygraph
  end subroutine set_default_output_parameters


  subroutine write_out(time, index, xval, yval, filename, nghost, &
 &                     sample_factor)
    implicit none

    ! All arguments are declared with intent IN to avoid accidental overwrites.
    real(kind=wp),                     intent(in) :: time
    integer,                           intent(in) :: index, nghost
    real(kind=wp), dimension(:),       intent(in) :: xval, yval
    character(len=*),                  intent(in) :: filename
    integer,                           intent(in) :: sample_factor

    logical, save               :: first = .true.
    integer, parameter          :: unit = 3
    integer, save               :: dim, first_index

    integer ::  count, first_point, last_point

    first_point = lbound(xval, 1) + nghost
    last_point  = ubound(xval, 1) - nghost

    if (first) then
      first_index = index

      if (first_point == last_point) then
         dim = 0 ! do 0D-output only
         write(*,*) 'problem is 0-dimensional, switching to 0D-output'
      else
         dim = 1 ! do 1D-output
         write(*,*) 'problem is 1-dimensional, switching to 1D-output'
      endif
    endif

     if (index == first_index) then
         open(unit, file = trim(filename), status = 'replace', err = 120)
     else
         open(unit, file = trim(filename), status = 'unknown', err = 120, &
    &         position = 'append')
     end if

    if (dim == 0) then  ! 0D - output
       write(unit, *) time, yval
    else                ! 1D - output
       write(unit, *)
       write(unit, *)

       ! Write time information and then the actual (optionally downsampled)
       ! data. Add two empty lines to indicate the end of the time slice.
       write(unit,'(a8,f16.10)') '"Time = ', time

       do count = first_point, last_point, sample_factor
          write(unit,'(2(e37.28e3))') xval(count), yval(count)
       end do

    endif
    close (unit) ! Close output file.

    first = .false.
    return

120 call file_error(filename)
  end subroutine write_out


  subroutine write_out_par(k, index, xval, yval, filename, parameters)!!!!!!!!!!!!!!1111

    use parameters_mod

    implicit none

    ! All arguments are declared with intent IN to avoid accidental overwrites.

    integer,                           intent(in) :: index, k !!!!!!!!!!1
    real(kind=wp), dimension(:),       intent(in) :: xval, yval
    character(len=*),                  intent(in) :: filename
    character(len=15) :: tim !for pygraph

    type(parameters_type),             intent(in) :: parameters

    integer :: stagdiff(1:9)

    character(len=128)          :: fullname
    logical, save               :: first = .true.
    integer, parameter          :: unit = 3
    integer, save               :: dim, first_index

    integer ::  count, first_point, last_point, coeflp

    if (parameters%grid%origin.eq.'nostag') then
	stagdiff = (/0,0,0,0,0,0,0,0,0/)
	coeflp = 0
    elseif (parameters%grid%origin.eq.'stag') then
	stagdiff = (/0,1,4,13,40,121,364,1093,3280/) ! to select the corresponding points (staggered grid at x = 0)
	coeflp = 1
    end if
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
!!stagdiff=0 ! set to zero to output the closest point to the left boundary, specially if all points are to be outputted
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    fullname = trim(file_prefix) // trim(filename) // trim(parameters%output%suffix)

! Change here to output ghost points
    first_point = lbound(xval, 1) + parameters%grid%nghost
    last_point  = ubound(xval, 1) - parameters%grid%nghost

    if (first) then
      first_index = index

      if (first_point == last_point) then
         dim = 0 ! do 0D-output only
         write(*,*) 'problem is 0-dimensional, switching to 0D-output'
      else
         dim = 1 ! do 1D-output
         write(*,*) 'problem is 1-dimensional, switching to 1D-output'
      endif
    endif

     if (index == first_index.and.parameters%id%id_type /= 'from_data') then
         open(unit, file = trim(fullname), status = 'replace', err = 120)
     else
         open(unit, file = trim(fullname), status = 'unknown', err = 120, &
    &         position = 'append')
     end if

    if (dim == 0) then  ! 0D - output
       write(unit, *) parameters%timer%t, yval
    else                ! 1D - output
       write(unit, *)
       write(unit, *)

       ! Write time information and then the actual (optionally downsampled)
       ! data. Add two empty lines to indicate the end of the time slice.
       write(tim,'(f15.10)') parameters%timer%t !for pygraph
       if (parameters%output%suffix.eq.'.yg') write(unit,'(a8,a)') '#Time = ', trim(adjustl(tim)) !'(a8,f16.10)' '(a8,e17.10e3)' '(a8,es12.5e3)'
       !if (parameters%output%suffix.eq.'.dat') write(unit,'(a8,f16.10)') '"Time = ', parameters%timer%t
       if (parameters%output%suffix.eq.'.dat') write(unit,'(a8,a)') '"Time = ', trim(adjustl(tim)) ! 2023/03/08: modified for compatibility with muninn
!write(*,*), first_point, last_point
!       do count = first_point + stagdiff(k) , last_point -coeflp/k, parameters%output%every_x_step
       do count = first_point + stagdiff(k) , last_point, parameters%output%every_x_step !change for staggered grid
          write(unit,'(2(e33.24e3))') xval(count), yval(count)
       end do
!       write(unit, *)
    endif
    close (unit) ! Close the output file.

    first = .false.
    return

120 call file_error(filename)
  end subroutine write_out_par

  subroutine file_error(filename)
    character(len = *), intent(in)    :: filename
    write (*, *) "File ", filename ," error: probably quota exceeded!"
    stop 'Program termination'
  end subroutine file_error


    subroutine write_t(k, index, xval, yval, filename, parameters)
    use parameters_mod
    implicit none
    integer,                           intent(in) :: index, k !!!!!!!!!!1
    real(kind=wp), 				       intent(in) :: xval, yval
    character(len=*),                  intent(in) :: filename
    type(parameters_type),             intent(in) :: parameters
    character(len=128)          :: fullname
    logical, save               :: first = .true.
    integer, parameter          :: unit = 1112
    integer, save               :: dim, first_index

    fullname = trim(file_prefix) // trim(filename) // trim(parameters%output%suffix)

    if (first) first_index = index
!print*, first

     if (index == first_index.and.parameters%id%id_type /= 'from_data') then
         open(unit, file = trim(fullname), status = 'replace')
     else
         open(unit, file = trim(fullname), status = 'unknown', position = 'append')
     end if

       write(unit, *) parameters%timer%t, yval

    close (unit) ! Close the output file.

    first = .false.
    return
  end subroutine write_t



  subroutine write_step(k, i, parameters, u, constr, x)!!!!!!!!!!!1
    use parameters_mod

    implicit none

    integer,                              intent(in)    :: i, k!!!!!!!!!!!!!!!111
    type(parameters_type),                intent(in)    :: parameters
    real(kind=wp), dimension(:,:),        intent(in)    :: u, constr
    real(kind=wp), dimension(:),          intent(in)    :: x

    real(kind=wp)  :: out(number_of_files,size(x))
    integer                     :: count

    out(1:size(u,1),:) = u

    out(size(u,1)+1:number_of_files,:) = constr


        do count = 1, number_of_files
            call write_out_par (k, i, x, out(count,:), file_names(count), parameters)!!!!!!!!!!!!!!!!!!!!!!!!!11
        end do

  end subroutine write_step

    subroutine change_file_names(file_names, parameters, string)

      type(parameters_type),                            intent(in)    :: parameters
      character(len = 120), dimension(number_of_files), intent(inout) :: file_names
      character(len = *),                               intent(in)    :: string
      integer i

      do i = 1, number_of_files
         file_names(i) = trim(file_names(i)) // '_' // &
              trim(parameters%moldef%deriv_method) // '_' // &
              string // ''
    enddo
  end subroutine change_file_names

end module output
