1D hyperboloidal serial code infrastructure in Fortran.
Current version by Alex Vano-Vinuales.

For compilation with gfortran (using make):
$ make

For recompiling:
$ make clean; make

For running the current configuration with the parameter file in the run folder:
$exe/scalar run/parameter_template.txt

To run convergence tests (this feature may have to be updated), with  the number of runs (usually X=3): 
exe/executable_name run/parameter_template.txt -conv_test X 

Relevant parameters in parameter file: 
- file_prefix = 'folder_name/simulation_tag_': folder_name must exist, of the code will complain ("error: probably quota exceeded!"). 

ygraph or muninn (https://git.tpi.uni-jena.de/srenkhoff/muninn) can be used for visualization, although of course you can use anything you want. 
