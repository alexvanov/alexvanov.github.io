
  phi    	= u(1,:)
  pi    	= u(2,:)
  psi   	= u(3,:)
  void   	= u(4,:)
  void   	= u(5,:)
  void    = u(6,:)

  du = u
  ddu = u
  u_diss = u

	last = n2v ! number of evolved quantities

  if (parameters%moldef%deriv_method == 'c8') then
     call mdiff_c8(du(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
     if (abs(eps).gt.1e-16) call mdiff_diss10(u_diss(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c6') then
     call mdiff_c6(du(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
     if (abs(eps).gt.1e-16) call mdiff_diss8(u_diss(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c4') then
     call mdiff_c4(du(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
     if (abs(eps).gt.1e-16) call mdiff_diss6(u_diss(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c2') then
     call mdiff(du(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
     if (abs(eps).gt.1e-16) call mdiff_diss4(u_diss(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  end if

  dphi    	= du(1,:)
  dpi   	  = du(2,:)
  dpsi     	= du(3,:)
  dvoid    	= du(4,:)
  dvoid   	= du(5,:)
  dvoid   	= du(6,:)

  nr0 = lbound(x,1)+parameters%grid%nghost
!  dx = x(nro+1)-x(nro)
  nro = ubound(x,1)-parameters%grid%nghost
!print*, nro, x(nro)
  dx = x(nro)-x(nro-1)

  if (parameters%moldef%spatial_order.eq.'second') then

  if (parameters%moldef%deriv_method == 'c8') then
     call m2diff_c8(ddu(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c6') then
     call m2diff_c6(ddu(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c4') then
     call m2diff_c4(ddu(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c2') then
     call m2diff(ddu(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  end if

  ddphi    	= ddu(1,:)
  ddpi    	= ddu(2,:)
  ddpsi   	= ddu(3,:)
  ddvoid   	= ddu(4,:)
  ddvoid   	= ddu(5,:)
  ddvoid   	= ddu(6,:)

  	if (parameters%moldef%eqsystem.eq.'linear') then

stop 'No linear equations set.'

    endif


if(.true.)then ! 05-11-2017: Pune, IUCAA, tests with the massive wave equation

  dru = u
  if (parameters%moldef%deriv_method == 'c8') then
     call mdiffone_c8(dru(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c6') then
     call mdiffone_c6(dru(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c4') then
     call mdiffone_c4(dru(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  else if (parameters%moldef%deriv_method == 'c2') then
     call mdiffone(dru(1:last,:), x(lbound(x,1)), x(ubound(x,1)), parameters%moldef%stencil_boundary, parameters%grid%nghost)
  end if
  drphi    	= dru(1,:)
  drpi     	= dru(2,:)
  drpsi   	= dru(3,:)
  drvoid   	= dru(4,:)
  drvoid   	= dru(5,:)
  drvoid   	= dru(6,:)

  rhs(3,:) = 0
  rhs(4,:) = 0
  rhs(5,:) = 0
  rhs(6,:) = 0
  constr(1,:) = 0
  constr(2,:) = 0
  constr(3,:) = 0

!! evolution equations are set here

  rhs(1,:) = ( pi )
  rhs(2,:) = ( advsten*(2*drpi*Kcmc*x)/3._wp + (1-advsten)*(2*dpi*Kcmc*x)/3._wp + omega**2*ddphi + mass**2*phi*(-1 - (Kcmc**2*x**2)/(9._wp*omega**2)) + pi*((2*Kcmc)/3._wp + (omega*Kcmc)/Sqrt(9*omega**2 + Kcmc**2*x**2)) + (omega*phi*(-9*omega**2 - 2*Kcmc**2*x**2 + 3*omega*Sqrt(9*omega**2 + Kcmc**2*x**2)))/(3._wp*x**2*Sqrt(9*omega**2 + Kcmc**2*x**2)) + (omega*dphi*(-9*omega**2 - 2*Kcmc**2*x**2 + 9*omega*Sqrt(9*omega**2 + Kcmc**2*x**2)))/(3._wp*x*Sqrt(9*omega**2 + Kcmc**2*x**2))  )


if (parameters%grid%origin.eq.'nostag'.or.parameters%grid%origin.eq.'misman') then
if (parameters%grid%origin.eq.'nostag') rhs(:,nr0) = 0
  rhs(1,nro) = ( pi(nro) )
  rhs(2,nro) = ( -(Kcmc**2*mass**2*xscri**2*ddphi(nro))/(18._wp*domega(nro)**2) - (2*Kcmc**2*mass**2*xscri*dphi(nro))/(9._wp*domega(nro)**2) + (2*Kcmc*xscri*dpi(nro))/3._wp + (2*Kcmc*pi(nro))/3._wp )

if (mass.gt.1d-10) u(1,nro) = 0._wp !! massive case
endif

endif


  else if (parameters%moldef%spatial_order.eq.'first') then
!First order in space

stop 'No first order in space system implemented.'

  else
	stop 'First or second order in space system?'

  end if

! Setting dissipation for all variables (here to avoid trouble when some rhs were introduced in another variables rhs).
  rhs(1,:) = eps*u_diss(1,:) + rhs(1,:)
  rhs(2,:) = eps*u_diss(2,:) + rhs(2,:)
  rhs(3,:) = eps*u_diss(3,:) + rhs(3,:)
  rhs(4,:) = eps*u_diss(4,:) + rhs(4,:)
  rhs(5,:) = eps*u_diss(5,:) + rhs(5,:)
  rhs(6,:) = eps*u_diss(6,:) + rhs(6,:)
