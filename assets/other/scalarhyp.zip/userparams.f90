module userparameters

  use prec

  implicit none

  ! The definitions of the different parameter types
  type physics_type
     character(len = 42):: equation
     real(kind=wp) 	:: gamma2, mu, mass, delta, nindex, xscri, Kcmc, propsign, xexc
     integer 		:: advsten
  end type physics_type

  ! For the initial data Gauss function
  type id_type
     character(len = 42):: id_type, simulation ! simulation can be sequencing, bisection or single
     real(kind=wp) :: center, a, sigma, da ! da is for sequencing runs.
     integer		:: noise
  end type id_type

  ! For the slicing
  type slice_type
     real(kind=wp) :: rmatchmin, rmatchmax, h
  end type slice_type

end module userparameters
